$(document).ready(function(){
	
	$('#register-bar-fname, #register-bar-lname').on('input', function(){
//firstname		
		fname = $('#register-bar-fname').val().toUpperCase();	
		lname = $('#register-bar-lname').val().toUpperCase();
		$('#register-bar-fname').val(fname);
		$('#register-bar-lname').val(lname);
		if(fname.match(/^[A-Z]{2,25}$/) && lname.match(/^[A-Z]{1,25}$/)){
			$('#name').text('');
			
		}
		else if(fname== ''){
			$('#name').css('color', 'red');		
			$('#name').html('<br>'+'Empty field');
	
		}
		else{
			$('#name').css('color', 'red');
			$('#name').html('<br>'+'Invalid name');
		}			
					
	});

	//email	
	$('#register-bar-email').on('input', function(){
		var email = $(this).val();	
	if(email.match(/^\S*([a-z0-9]{3,15})+\S*(.*)+\@+([a-z]{2,15})+((\.)+([a-z0-9]{2,15}))+$/g)){
			$('#email').text('');
			
		}
		else if(email== ''){
			$('#email').css('color', 'red');		
			$('#email').html('<br>'+'Empty field');
	
		}
		else{
			$('#email').css('color', 'red');
			$('#email').html('<br>'+'Invalid email');
		}
					
					
	});

	//mobile	
	$('#register-bar-mobile').on('input', function(){
		var mobile = $(this).val();	
	if(mobile.match(/^([0-9]{10})$/g)){
			$('#mobile').text('');
			
		}
		else if(mobile== ''){
			$('#mobile').css('color', 'red');		
			$('#mobile').html('<br>'+'Empty field');
	
		}
		else{
			$('#mobile').css('color', 'red');
			$('#mobile').html('<br>'+'Invalid mobile');
		}
					
					
	});

	//password	confirmation
	$('#register-bar-pw, #register-bar-re-pw').on('input', function(){
		var paswd = $('#register-bar-pw').val();	
		var repaswd = $('#register-bar-re-pw').val();
		
		if(paswd === repaswd && paswd.length >= 8 && repaswd.length >= 8){
			$('#password').text('');
		}
		else if(paswd.length < 8 && repaswd.length < 8){
			$('#password').css('color', 'red');
			$('#password').html('<br>'+'password must have 8 characters');
		}

		else{
			$('#password').css('color', 'red');
			$('#password').html('<br>'+'password must be matched');
		}
				
	});
	
//controlling submission	
	$('#register-bar-fname,'+
			' #register-bar-lname, #register-bar-email,'+
					'#register-bar-mobile, #register-bar-pw,'+
							'#register-bar-re-pw').on('input', function(){
		
		if($('label').text() == ''){
					$('#register-bar-sub').attr('disabled', false);
		}
		else {
			$('#register-bar-sub').attr('disabled', true);
		}
	});

});



