
$(document).ready(function(){
// disable the cut/copy/paste block

	$('body').bind('cut copy paste', function(event){
			
			event.preventDefault();
		});
var i = 1;
var j = -1;
if($('img').attr('src')){
	
	$('#NQ').on('click', ajax);

	//ajax question bank code		

	ajax();	
		function ajax(){

		j = j+1;
		var personid = $.trim($(".userid").text());
		var option = $("input[name='Q']:checked").val();
		var data='A='+option+'&Q=Q'+j+'&id='+personid;

		$.ajax({
			url:'./demo-exam-script.php',
			type:'POST',
			data : data,
			dataType:'text',
			cache: false,
			success: function (response){
		
				var question = $.parseJSON(response)['Q'+i];
				console.log(question);
				var answer = $.parseJSON(response)['A'+i];	
				console.log(answer);
				console.log(data);
				
				$('.content-description').text(question);
				$('#Opt1').text(answer[0]);
				$('#Opt2').text(answer[1]);
				$('#Opt3').text(answer[2]);
				$('#Opt4').text(answer[3]);	
				i = i + 1;	

			}
			
		
		});
							

	}
	
}

	
});

//timer code
var h = '00';
var m = 59;
var s = 60;

	
function timer(){
	if($('img').attr('src')){
		if(s<=60 && s >0){
		s=s-1;
		window.setTimeout(timer,1000);
			if(s<10){
				if(m >=10){
					document.getElementById('time').innerHTML = h+':'+m+':'+'0'+s;
				}
				else {
					document.getElementById('time').innerHTML = h+':'+'0'+m+':'+'0'+s;
					}
			}	
			else{document.getElementById('time').innerHTML = h+':'+ m +':'+s;}
			}

		else {
			if (m<60 && m>00){
			window.clearTimeout(timer,0); 
			s= 61;
			s = s-1;
			window.setTimeout(timer,0);
			m = m-1;
			}
			else{
				window.clearTimeout(timer,0);
				
			}
	}	}
}