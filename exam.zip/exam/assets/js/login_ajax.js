$(document).ready(function(){

	// disable the cut/copy/paste block
	$('body').bind('cut copy paste', function(event){
			
			event.preventDefault();
		});
		
	//disable autofill block	
	$('input').attr('autocomplete', 'off');

	//validate UserID & password and controlling button
	$('#login-bar-user').on('input', function(){
		var str = $('#login-bar-user').val();
		if(str.match(/^[0-9]{3}$/)){
			$('#validation-data').text('');

		}
		else {
			$('#validation-data').css('color', 'red');
			$('#validation-data').text('Invalid UserID');
		}
		
	});
	
	$('#login-bar-user, #login-bar-pw').on('input', function(){

		if($('#login-bar-pw').val()!=='' && $('#validation-data').text()===''){
			
			$('#login-bar-sub').attr('disabled', false);

		}
		else {
			$('#login-bar-sub').attr('disabled', true);
		}
		
	});

	//form submission
	$('form').submit(function(event){
		
			event.preventDefault();//prevent normal submission
			
			var login = $('#login-bar-sub').val();
			var userid = $('#login-bar-user').val();			
			var data = $(this).serialize()+"&login="+login;
			//ajax
				$.ajax({
				type: "POST",
				url: 'login-script.php',
				data: data, 
				cache:false,
				success: function(res){
							if($.trim(res) ==='Login'){
							location.assign('./demo-exam.php?regid='+userid);
							}
							else alert(res);
								
															
				}
			});
			
	});

});