$(document).ready(function(){
// disable the cut/copy/paste block

$('body').bind('cut copy paste', function(event){
		
		event.preventDefault();
	});
	
//disable autofill block	
$('input').attr('autocomplete', 'off');
	
//register response
if($('#result').text()=='Please fill all information'){
	
	$('#result').css({'color':'red',
							'background-color':'black','font-weight':'bold', 'display':'block'});

}	
else{
	$('#result').css({'color':'green',
							'background-color':'black','font-weight':'bold', 'display':'block'});

		
	$('.login').html('<a href="./login.php"><button style="width:250px; height: 30px;">Go Login Page </button><a>');
				
	}
	
});
