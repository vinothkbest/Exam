<?php
session_start();

require_once('db_connection.php');

if(isset($_GET['regid']) && isset($_SESSION)):
		$userid = mysqli_real_escape_string($conn, $_GET['regid']);
		$query = "SELECT NAME, PHOTO_NAME FROM user_photo WHERE USERID = $userid";
		$query_exec = mysqli_query($conn, $query);
		$fetch_photo_data = mysqli_fetch_assoc($query_exec);
?>

<html>
<title>Online Exam</title>
<head>
<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1.0'></meta>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<link rel='stylesheet' href='assets/css/demo-exam-style.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/demo-exam-script.js'></script>
</head>	
<body style='width:scrollwidth; height:scrollheight'  Onload='timer()'>
<div class='head-grid' id ='header'>
<h3>Demo Exam</h3>
<p class='time-box' id ='time'></p>
</div>
<div id = 'exam-head' class='login-head'>
<img src="<?php if(isset($fetch_photo_data['PHOTO_NAME'])){echo './userphoto/'.$fetch_photo_data['PHOTO_NAME'];}?>" width = '120px' height = '120px'></img>
<p>Online-Exam</p>
<p class='person'>
<?php  
	if(isset($fetch_photo_data['NAME']))	{
	echo '<strong>Name:</strong> '. $fetch_photo_data['NAME'].'<br>'; 
	}
?>
<label class='userid' hidden><?php  
	if(isset($_GET['regid']))	{
	echo $_GET['regid']; 
	}
?><label>
</p>
</div>
<div class='content-wrapper'>
<section class='content-description'>
</section>
<section class='query-answer' id = 'query-answer'>
<input type = 'radio' name = 'Q' id = 'ans1' value = 'A'><label id='Opt1'></label>
<br>
<input type = 'radio' name = 'Q' id = 'ans2' value = 'B'><label id='Opt2'></label>
<br>
<input type = 'radio' name = 'Q' id = 'ans3' value = 'C'><label id='Opt3'></label>
<br>
<input type = 'radio' name = 'Q' id = 'ans4' value = 'D'><label id='Opt4'></label>
</section>
<section class='submission'>
<button id ='NQ'>Save and Next </button>
<a href="<?php echo 'result.php?id='.$_GET['regid']?>"><button style="width:100px; height: 50px;">Submit Exam</button></a>
</section>
</div>
</body>
</html>

<?php else : header('location:login.php'); endif;?>