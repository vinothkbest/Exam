Exam Folder is root folder and index.php is root file.

Part I

1) Admin Page has Built your Question and respective answer.

2) These questions are appended in "EvaluationFile.txt". in the same folder


Part II

1) Index Page is Register Page.

2) After Registration Green color message given on same page bottom, that has Exam ID.

3) Dont Forget Password. Becauz it will hashed in db.

4) Go Login Page. Give Your credentials

5) Exam Window will be opened.

6) Once Submit that, result status is produced. It has only how many questions are attempted.



