<?php 
if(isset($_GET['id'])) :

$id = $_GET['id'];

//db connection
require_once('./db_connection.php');

	$sql = "SELECT * FROM `mark` WHERE USERID = '$id'";

	$query_exec = mysqli_query($conn, $sql); ?>

<!DOCTYPE html>
<html>
<title>Online Exam</title>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="cache-control" content='no store'>
<meta http-equiv="cache-control" content='no chache'>
<meta http-equiv="expires" content='0'>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/register-validation.js'></script>
</head>	
<body>
	<div id ='header'>
		<h2 style="text-align:center">Result in Percent</h2>
	</div>

<div id="result" style="display: grid;">
	<p class="result" style="display: none;"><?php echo mysqli_num_rows($query_exec);?></p>
	<p style="text-align: center; margin-top: 100px;"> <?php echo mysqli_num_rows($query_exec) . " questions are attended! Please wait for your result!"; ?></p>
	<div class="result" style="text-align: center; margin-top: 100px;">
		<canvas id="canvas" width="200" height="200" style="background: black"></canvas>
	</div>

</div>



<?php endif; ?>

<div class="logout" style="text-align: center; margin-top: 100px;">
	<a href="login.php"><button style="width:240px; height: 50px">Logout</button></a>
</div>
<?php include('footer.php'); ?>




<script type="text/javascript">
var result = $('.result').text();
console.log(result);
var context = document.getElementById('canvas').getContext('2d');
var auto_load = 0, start=5, diff; /*auto load and at which point to start count*/
var cw=context.canvas.width/2; /*fixed center*/
var ch=context.canvas.height/2;

function progressbar(){
		diff=(auto_load/100)*Math.PI*2;
		context.clearRect(0,0,400,200);
		context.beginPath();
		context.arc(cw,ch,75,0,2*Math.PI,false);
		context.strokeStyle='grey';
		context.stroke();
		context.fillStyle='white';
		context.strokeStyle='white';
		context.textAlign='center';
		context.lineWidth=10;
		context.font = '18pt times';
		context.beginPath();
		context.arc(cw,ch,75,start,diff+start,false);
		context.stroke();
		context.fillText(auto_load,cw+2,ch+6);
		if(auto_load>=result){
			clearTimeout(progressbar);
		}
		auto_load = auto_load+1;
}

var progressbar=setInterval(progressbar,150);
</script>
