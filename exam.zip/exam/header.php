<html>
<title>Online Exam</title>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="cache-control" content='no store'>
<meta http-equiv="cache-control" content='no chache'>
<meta http-equiv="expires" content='0'>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/register-validation.js'></script>
<script type="text/javascript" src="assets/js/nocontentcopied.js"></script>
<script src='assets/js/login_ajax.js'></script>
</head>	
<body>
	<div id ='header'>
		<h2 style="text-align:center">Exam</h2>
	</div>