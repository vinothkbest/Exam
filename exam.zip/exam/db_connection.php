<?php
$database = 'exam';
$server = 'localhost';
$db_user='root';
$db_password='';
$conn = mysqli_connect($server, $db_user, $db_password, $database) or die(mysqli_connect_error());

?>