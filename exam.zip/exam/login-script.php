<?php

if(isset($_POST['login'])){
	
//db connection
require_once('db_connection.php');

$regid = mysqli_real_escape_string($conn,$_POST['regid']);
$password = crypt((mysqli_real_escape_string($conn, $_POST['password'])),'$1$niville$');

	$query = "SELECT USERID, NAME, USER_PASSWORD FROM register WHERE USERID = $regid";
	$query_exec = mysqli_query($conn, $query);
	if(mysqli_num_rows($query_exec) === 1){
	
			$fetch_user_data = mysqli_fetch_assoc($query_exec);
		
			if(hash_equals($password, $fetch_user_data['USER_PASSWORD'])){
				echo 'Login';
			}		
			else {
				echo 'Password incorrect';
			}
	}
	else {
		echo 'Please check UserID';
	}
	
}

?>

