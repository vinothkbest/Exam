<?php 

require_once('./db_connection.php');

if(isset($_POST['id']) && isset($_POST['Q']) && $_POST['Q'] !=="Q0" && isset($_POST['A'])) :
	$userid = mysqli_real_escape_string($conn, $_POST['id']);
	$QNumber = mysqli_real_escape_string($conn, $_POST['Q']);
	$uservalue = mysqli_real_escape_string($conn, $_POST['A']);
	$query = "Insert into Mark (USERID, QUESTID, ANSWER) VALUES('$userid','$QNumber' ,'$uservalue')";
	
	mysqli_query($conn, $query);

endif; 
//file reader in json format
$file=fopen('./EvaluationFile.txt', 'r');

$array = array();

while(!feof($file)){
array_push($array,fgets($file)); 


}

$Q_value = array();
$A_value = array();
foreach($array as $index=>$string){
	
	if($index%5===0){
		array_push($Q_value, $string);
		
	}
	else {
		array_push($A_value, $string);
		
	}
}

$Q_key = array();
$A_key = array();
$key = 1;
while($key <= count($Q_value)){
	
		array_push($Q_key, 'Q'.$key);
				array_push($A_key, 'A'.$key);
		$key++;
}

$Questions = array_combine($Q_key, $Q_value);

$A_value = array_chunk($A_value, 4);

$Answers = array_combine($A_key, $A_value);

$bank = array_merge($Questions, $Answers);


echo json_encode($bank);

fclose($file);








?>