<html>
<title>Online Exam</title>
<head>
<meta http-equiv="cache-control" content='no store'>
<meta http-equiv="cache-control" content='no chache'>
<meta http-equiv="expires" content='0'>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/register-validation.js'></script>
<script type="text/javascript" src="assets/js/nocontentcopied.js"></script>
</head>	
<body>
<div id ='header'>
<h3 style="text-align: center;">Exam</h3>
</div>
<div class='login-head'>
	<h3>Admin</h3>
</div>
<form method="post" action="admin.php">
	<br>
	<br>
	<div><label>Question</label>
	<br>
	<br>
	<input type="text" name="question" placeholder="Type a Question"  style="width:500px;"></div>
	<div>
	<br>
	<br>
	<label>Choices</label>
	<br>
	<br>
	<input type="text" name="answer1" placeholder="Choice1">
	<input type="text" name="answer2" placeholder="Choice2">
	<input type="text" name="answer3" placeholder="Choice3">
	<input type="text" name="answer4" placeholder="Choice4">
	<br>
	<input type="submit" name="submit">
	</div>

</form>
<?php include('footer.php');

if(isset($_POST['question']) && isset($_POST['answer1']) && isset($_POST['answer2']) && isset($_POST['answer3']) && isset($_POST['answer4']))  :


$fh = fopen('EvaluationFile.txt', 'a+');

if(empty(filesize('EvaluationFile.txt'))) :
	$data = $_POST['question'] . "\n" . $_POST['answer1'] . "\n" . $_POST['answer2']. "\n" . $_POST['answer3']. "\n" . $_POST['answer4'];
else :

$data = "\n" . $_POST['question'] . "\n" . $_POST['answer1'] . "\n" . $_POST['answer2']. "\n" . $_POST['answer3']. "\n" . $_POST['answer4'];

endif;

fwrite($fh, $data);

echo 'New Question is added';

endif;

?>

