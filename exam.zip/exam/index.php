<?php
if(isset($_POST['submit'])){

//db connection
require_once('./db_connection.php');

//user information from register form
if(!empty($_POST['fname'])&&!empty($_POST['lname']) 
	&& 	!empty($_FILES['photo'])&& !empty($_POST['email']) && !empty($_POST['password'])){
	
$name = mysqli_real_escape_string($conn, $_POST['fname']).' ' . mysqli_real_escape_string($conn, $_POST['lname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
$password = crypt((mysqli_real_escape_string($conn, $_POST['password'])),'$1$niville$');

//data-storage

$sql_data = "CALL registerprocedure('$name', '$email', '$mobile', '$password');";

if(mysqli_query($conn, $sql_data)){


		//user photo process
		$image = $_FILES['photo'];
		$image_name = $image['name'];
		$image_type = $image['type'];
		$image_path = $image['tmp_name'];
		$image_size = $image['size'];

		if(move_uploaded_file($image_path, './userphoto/'.$image_name)){
			
			//fetching 
			$sql_info = "SELECT USERID, NAME FROM register WHERE Email = '$email';";
			
			$query_exec = mysqli_query($conn, $sql_info);
			$data = mysqli_fetch_assoc($query_exec);
			
			$data_id = $data['USERID'];
			$data_name = $data['NAME'];
			
			//storing photos
			$sql_photo = "INSERT INTO `user_photo`(`USERID`, `NAME`, `PHOTO_NAME`) VALUES ('$data_id', '$data_name', '$image_name');";

			if(mysqli_query($conn, $sql_photo)){
				
				$response = 'Registered successfully! and Your Registered ID is '. $data_id;
		
			}
		}
		  }

}

else $response = 'Please fill all information';

}
?>
<html>
<title>Online Exam</title>
<head>
<meta http-equiv="cache-control" content='no store'>
<meta http-equiv="cache-control" content='no chache'>
<meta http-equiv="expires" content='0'>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/register-validation.js'></script>
<script type="text/javascript" src="assets/js/nocontentcopied.js"></script>
</head>	
<body>
<div id ='header'>
<h3 style="text-align: center;">Exam</h3>
</div>
<div class='register-head'>
<p>Exam-Registration</p>
</div>
<div class = 'register-wrapper'>
	<form action='index.php' id= 'register-bar' method = 'POST' enctype = 'multipart/form-data'>
		<input id ='register-bar-fname' name = 'fname' type = 'text' placeholder='Enter First Name'>
		<?php echo '<br>';?>
		<input id ='register-bar-lname' name = 'lname' type = 'text' placeholder='Enter Last  Name'>
		<label id = 'name'></label>
		<?php echo '<br>';?>
		<input id ='register-bar-email' name = 'email' type = 'text' placeholder='Enter Email'>
		<label id = 'email'></label>
		<?php echo '<br>';?>
		<input id ='register-bar-mobile' name = 'mobile' type = 'text' placeholder='Enter Mobile'>
		<label id = 'mobile'></label>
		<?php echo '<br>';?>
		<input id ='register-bar-pw' name = 'password' type = 'password' placeholder='Enter Passwaord'>
		<?php echo '<br>';?>
		<input id ='register-bar-re-pw' name = 're-password' type = 'password' placeholder='Re-enter Passwaord'>
		<label id = 'password'></label>
		<?php echo '<br>';?>
		<input id ='register-bar-photo' name = 'photo' type = 'file'>
		<?php echo '<br>';?>
		<input id ='register-bar-sub' name = 'submit' type = 'Submit' value='REGISTER'>
		<?php echo '<br>';?>
		<p id='result'><?php if(isset($response)) echo $response?></p>
	</form>
	<div class="login" style="text-align: center;">
		<a href="login.php"><button style="width:240px; height: 50px">Go Login Page</button></a>
	</div>
</div>
</body>
</html>
