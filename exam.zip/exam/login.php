<?php
session_start();

unset($_SESSION);

session_destroy();

?>
<html>
<title>Online Exam</title>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="cache-control" content='no store'>
<meta http-equiv="cache-control" content='no chache'>
<meta http-equiv="expires" content='0'>
<link rel='stylesheet' href='assets/css/login-regiser.css'>
<script src='assets/js/jquery.min.js'></script>
<script src='assets/js/register-validation.js'></script>
<script type="text/javascript" src="assets/js/nocontentcopied.js"></script>
<script src='assets/js/login_ajax.js'></script>
</head>	
<body>
	<div id ='header'>
		<h2 style="text-align:center">Exam</h2>
	</div><div class='login-head'>
	<p>Exam-login</p>
</div>
<div>
	<form id= 'login-bar' method='POST' action = 'login-script.php'>
		<input id ='login-bar-user' type = 'text' name='regid' placeholder='Enter Regsiter Number'>
		<?php echo '<br>';?>
		<input id ='login-bar-pw' name='password' type = 'password' placeholder='Enter Passwaord'>
		<?php echo '<br>';?>
		<input id ='login-bar-sub' name ='login' type = 'Submit' value='LOGIN'>
		<p id='validation-data'></p>
	</form>

	<div>
		<ul>
			<li>Dont click submit button before all question will be answered</li>
		</ul>
	</div>
</div>
<?php

if(isset($_POST['regid'])) :
$_SESSION['id'] = $_POST['regid'];
endif;

include('footer.php');?>

<style type="text/css">
	input, button{
		outline: none;
	}
</style>